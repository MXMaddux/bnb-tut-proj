const InfoPage = () => {
  return (
    <div>
      <h1 className="text-7xl">Info Page</h1>
    </div>
  );
};

export default InfoPage;

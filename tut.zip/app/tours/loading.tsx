"use client";

function loading() {
  return <span className="text-xl capitalize">loading...</span>;
}
export default loading;

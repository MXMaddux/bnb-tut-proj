function AboutPage() {
  return (
    <div>
      <h1 className="text-7xl">About Page </h1>
    </div>
  );
}
export default AboutPage;
